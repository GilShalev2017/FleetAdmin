'use strict';

const rclnodejs = require('rclnodejs');

rclnodejs.init().then(() => {
  const node = rclnodejs.createNode('subscription_amr_location');
  const publisher = node.createPublisher('std_msgs/msg/String', 'newLocation');

  const bounds = [
    [-116, -240],
    [116, 240],
  ];

  const amr = {
    id: 1,
    markerColor: 'red',
    position: [15, -195],
    movement: [0.05, 3]
  };

  let reverseDummyAmrs = false;

  const checkIfAmrInBounds = (newPosition) => {
    if (newPosition[0] < bounds[0][0] || newPosition[0] > bounds[1][0]) {
      return false;
    }
    if (newPosition[1] < bounds[0][1] || newPosition[1] > bounds[1][1]) {
      return false;
    }
    return true;
  };

  setInterval(() => {
    let prevCircleCenter = amr.position;
    let newPosition = [prevCircleCenter[0] + amr.movement[0], prevCircleCenter[1] + amr.movement[1]];
    if (reverseDummyAmrs) {
      newPosition = [prevCircleCenter[0] - amr.movement[0], prevCircleCenter[1] - amr.movement[1]];
    }
    if (!checkIfAmrInBounds(newPosition) || newPosition[1] > 115 || newPosition[1] < -195) {
      reverseDummyAmrs = !reverseDummyAmrs;
      newPosition = prevCircleCenter;
    }
    amr.position = newPosition;
    const amrStr = JSON.stringify(amr);
    console.log(amrStr);
    publisher.publish(amrStr);
  }, 500);

  rclnodejs.spin(node);
});
