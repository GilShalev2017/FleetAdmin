const mqtt = require('mqtt');
const consts = require('./consts');
const client  = mqtt.connect(consts.MQTT_DOMAIN, consts.MQTT_DOMAIN_LOGIN);

client.on('connect', function () {
  console.log('connected');
  client.subscribe('presence', function (err) {
    if (!err) {
      let count = 0;
      setInterval(() => {
        client.publish('presence', 'Hello mqtt#' + count++);
      }, 1000);
    }
  });
});

client.on('message', function (topic, message) {
  // message is Buffer
  console.log(message.toString());
  //client.end();
});