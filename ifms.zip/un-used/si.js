const si = require('systeminformation');

const getAmrStaticData = () => {
  si.dockerImages().then((dockerImagesData) => console.log(dockerImagesData.filter(d => d.repoTags != null && d.repoTags.length > 0).map(d => d.repoTags[0])));
};

getAmrStaticData();
